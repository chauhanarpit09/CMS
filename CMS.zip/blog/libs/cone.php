<?php
	$con = mysqli_connect('localhost','root','','phpblog');
	if($con == false)
	{
		echo  " connection not established";
	}
?>